%% GREEKS - Option greeks by orthogonal polynomials

function [Call, Delta, Gamma, VS, Vega] = greeks(varargin)


H=varargin{1};
m=varargin{2};
bt=varargin{3};
if nargin>3
    r=varargin{4};
else
    r=0;
end
if nargin>4
    tau=varargin{5};
else
    tau=1;
end

%% Call prices
Call=exp(-r*tau)*H*m;

%% Deltas
HK=H(:,2:end);
Delta=HK(:,1);
if isempty(bt)==0
    p=size(bt,2);
    n=size(bt,1)+1;
    m1=m(2);
    for j=1:p
        Dj=0;
        for i=1:n-1
            Dj=Dj+HK(:,i+1)*bt(i,j);
        end
        Dj=Dj*j*m1^(j-1);
        Delta=Delta+Dj;
    end
end

%% Gammas
Gamma=zeros(size(Delta));
if isempty(bt)==0
    for j=1:p-1
        Dj=0;
        for i=1:n-1
            Dj=Dj+HK(:,i+1)*bt(i,j+1);
        end
        Dj=Dj*(j+1)*j*m1^(j-1);
        Gamma=Gamma+Dj;
    end
end

%% Vegas (as sensitivities wrt variance swaps)
Vega=zeros(size(Delta));

% Variance swap (undiscounted to match that H*m gives undiscounted Call)
if nargin>5
    VS=exp(r*tau)*varargin{6};
else
    C=1;
    VS=1e4/tau*(m(3)/(m(2))^2-C);
end

if isempty(bt)==0
    for j=1:p
        Dj=0;
        for i=1:n-1
            if bt(i,j)>0
                Dj=Dj+HK(:,i+1)*m(j+1)*log(m(j+1)/m1^j)/VS;
            end
        end
        Vega=Vega+Dj;
    end 
end
% Discounting variance swap
if nargin>5
    VS=exp(-r*tau)*VS;
end
