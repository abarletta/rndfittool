%% CLEANDATA
% Removes convexity and monotony inconsistencies from option prices
%
% cldata=cleandata(K, call, put)
%
% This procedure transforms call and put price curves into dereasing and
% increasing convex functions. Points violating above conditions are
% replaced with the linear approximation obtained from neighboors.

function cldata=cleandata(K, call, put)

[vc, vp]=checkPrices(K,call,put);
flag=~(isempty(vc)&&isempty(vp));
count=1;
while (flag)&&(count<=length(K))
    if ~isempty(vc)
        for i=1:length(vc)
            I=vc(i);
            if I>=2
                if call(I-1)<=call(I)
                    call(I)=call(I-1)*.995;
                end
            end
            if I<=length(K)-1
                if call(I+1)>=call(I)
                    call(I+1)=call(I)*.995;
                end
            end
            if (I>=2)&&(I<=length(K)-1)
                y0=call(I-1);
                yf=call(I+1);
                x0=K(I-1);
                xf=K(I+1);
                y=(yf-y0)/(xf-x0)*(K(I)-x0)+y0;
                call(I)=min(call(I),y);
            end
        end
        for i=1:length(vp)
            I=vp(i);
            if I>=2
                if put(I-1)>=put(I)
                    put(I)=put(I-1)*1.005;
                end
            end
            if I<=length(K)-1
                if put(I+1)<=put(I)
                    put(I+1)=put(I)*1.005;
                end
            end
            if (I>=2)&&(I<=length(K)-1) 
                y0=put(I-1);
                yf=put(I+1);
                x0=K(I-1);
                xf=K(I+1);
                y=(yf-y0)/(xf-x0)*(K(I)-x0)+y0;
                put(I)=max(put(I),y);
            end
        end
        [vc, vp]=checkPrices(K,call,put);
        flag=~(isempty(vc)&&isempty(vp));
        count=count+1;
    end
end
cldata=[call,put];
