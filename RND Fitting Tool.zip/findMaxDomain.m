%% findMaxDomain
%
% This function is called by calibrate.m
%
% Version: May 2018

function [F,DF]=findMaxDomain(f,q,x)

F=integral(f,0,x)-q;
DF=f(x);

end
