%% FinDiff - Discrete derivatives by central finite difference
% [D,DD] = FinDiff(x,u)
%
% Input:
%       x  -  Function domain
%       u  -  Function values at domain points
%
% Output:
%       D  -  First order derivatives at domain points
%      DD  -  Second order derivatives at domain points
%
% Note: to compute derivatives at extreme points, linear interpolation is
% used.

% Author: Andrea Barletta
% Year: 2018
function [D,DD]=FinDiff(x,u)
%% Uniforming data size
if isrow(x)
    x=x';
end
if isrow(u)
    u=u';
    wasRow=true;
else
    wasRow=false;
end
%% Extending option
h=min(diff(x));
xstar=[x(1)-h; x; x(end)+h];
u=interp1(x,u,xstar,'linear','extrap');
D=(u(3:end)-u(1:end-2))./(xstar(3:end)-xstar(1:end-2));
Dminus=diff(u(1:end-1))./diff(xstar(1:end-1));
Dplus=diff(u(2:end))./diff(xstar(2:end));
DD=2*(Dplus-Dminus)./(xstar(3:end)-xstar(1:end-2));
if wasRow
    D=D';
    DD=DD';
end

end
