%% ORTAPPROX_FUNC - ortogonal approximation
%
% f=ortapprox_func(kf, KerMom, c, x)
%
% N.B. this function is identical to ortapprox but returns f evaluated at
%      x instead of an anonymous function.
%
% See also: calibrate, fmincon
%
% Last modified: May 2018

function f=ortapprox_func(kf, w, c, x)

a=flip(w'*c');
f= kf(x).*polyval(a,x);

end % END OF FUNCTION
