%% CONSTRINTINTERCEPT - Constraint function to ensure positive RND
% [cineq,ceq]=constraintintercept(X,beta,Mu,Sigma,delta,W,K0,Kmax,kernelDensity,kerpar)
% 
% This function is used in fmincon to constrain the estimated RND to be
% positive on its entire domain. For details, see the code section
% about PCA-based regression with option 'robustness' in in calibrate.m.
%
% See also: fmincon, calibrate
%
% Last update: May 2018

function [cineq,ceq]=constraintintercept(sigma,beta,MS,delta,W,Kmax,kf,w,IX)

thresh=0;
ceq=delta-mean(MS*(W*beta));
NPC=length(beta);
beta_PCA0=W(:,1:NPC)*beta;
c=zeros(1,length(sigma)+sum(IX==0));
c(IX)=beta_PCA0./sigma';
c=[1;c']';
% Finding the coefficients of the polynomial correcting term p, i.e.
% f(x) = kf(x)*p(x), p(x)=a(1)+a(2)*x+...+a(n+1)*x^n
a=w'*c'; 
I=find(abs(a)>0,1,'last');
a=a(1:I);
% Finding the coefficients of p'
b=flip(a(2:end).*(1:length(a)-1)'); % Flipping to make it compatible with roots
x0=roots(b);
x0=x0((x0>=0)&(imag(x0)==0)&(x0<=Kmax));
% Finding minimum
cineq=-min(polyval(flip(a),union(x0,[0;Kmax])))-thresh; % Flipping to make it compatible with polval
end
