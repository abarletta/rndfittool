function [vc,vp]=checkPrices(K,call,put)
%% [vc,vp]=checkPrices(K,call,put)
% Check integrity of call and put price curves
%
% This function returns the domain points where call and put price curves
% reveal monotony or concavity issues.
%
% Input:
%
%          K - strike domain
%       call - call prices
%        put - put prices
%
% Output:
%
%         vc - violations indexes related to call prices
%         vp - violations indexes related to put prices

[DCall,DDCall]=FinDiff(K,call);
vc=find(((round(DCall,5)>=0)|(round(DDCall,5)<0))&(call>0));
[DPut,DDPut]=FinDiff(K,put);
vp=find(((round(DPut,5)<=0)|(round(DDPut,5)<0))&(put>0));
