%% Editing input data
%
%% Notations used in this page
% 
% * $m$   number of total observations i.e. twice the number of strikes
% * $K_i$   strikes related to observed option prices
% * $c^{obs}_i$, $p^{obs}_i$   observed call and put prices
%
%% Basic operations
%
% * Reset: reset data as it was passed to the editor.
% * Undo: cancel previous operation.
% * Redo: redo an operation when canceled.
% * Cancel: quit the editor without applying changes.
% * Apply and Exit: apply changes to data and quit the editor.
% * Export Data: export current input data into a compatible MAT-file.
%
%% Estimating mean and variance
% In the left-panel the user can guess values for mean and variance to be
% passed as initial condition during the optimization of kerenl parameters.
% Alternatively, values for mean and variance can be automatically determined
% by the algorithm (simply press _Estimate_) as follows.
%
% _Mean_ is set as forward $F$ value inferred from observed prices as 
%
% $\frac{2}{m}\sum_{i=1}^{\frac{m}{2}}\left( c^{obs}_i-p^{obs}_i+K_i \right)$
%
% _Variance_ is inferred through the following formula 
%
% $3(K_{q}-F)^2+\sum_{K_i
% < K_{q}}p^{obs}(K_i) \Delta K_i + \sum_{K_i > K_{q}}c^{obs}(K_i) \Delta K_i$
%
% where 
% 
% $q := \arg\max\left\lbrace K_i \; : \; K_i \leq F \right\rbrace, \quad \Delta K_i = \frac{1}{2}(K_{i+1}-K_{i-1})$ 
%
% *Note:* press _Update_ in order to save and apply any change that has been
% made. 
%
%% Correcting data
% These tools are intended to adjust small data inconsistencies. Misuse may
% lead to drastic changes and make data unusable.
%
% _Smoothness:_ this tool reduces possible irregularities of price curves. Please be 
% aware that smoothening prices may result in inflating violations of Put-Call parity. 
%
% *Note:* price curves are not required to be smooth for the method to be consistent.
%
% _Monotony/Concavity:_ this tool eliminates possible inconsistencies related to wrong
% monotony or concavity. Points affected by monotony or concavity issues are marked
% in red and should completely disappear after the tool has been applied. Normally, 
% this tool sensibly reduces violations of Put-Call parity.
%
% _Adjust Put-Call parity:_ this tool adjusts Put-Call parity violations greater than 
% a tolerance level. Adjustements are made so that modifications ratio are exactly the
% same in percentage terms but with different sign, on each pair of call and put 
% prices. The size of each Put-Call parity violation is determined in terms of
% deviations from the forward value as
%
% $\left( c^{obs}_i-p^{obs}_i+K_i \right)-F$.
%
% Default tolerance level is determined as
%
% $\max_{i}|\left( c^{obs}_i-p^{obs}_i+K_i \right)-F|$.
%
% When $F$ is automatically estimated then the violations are determined as
% deviations of forward values, induced by Put-Call parity for every strike,
% from their mean. Therefore, the tolerance level for Put-Call parity
% violations should be presumably given by the Bid-Ask spread regarding 
% the underlying future price observed on the market, as no profitable 
% arbitrage is produced by violations below this value. However, this 
% tolerance level can be changed according to users needs.
%
% _Annualized interest rate (%):_ this tool allows to change the annualized
% interest rate $\bar{r}$ used to discount prices by a factor $e^{-\bar{r} T}$,
% where $T$ denotes the time to maturity, in years.
% 
% A new value $r^*$ replacing $\bar{r}$ can be automatically inferred from
% input data as 
%
% $r^* = \frac{1}{T}\log(U)+\bar{r}$,
%
% where $U$ solves the following optimization problem
% 
% $U = \arg\min_{x \geq e^{-\bar{r} T}} f_{obj} (x)$
%
% $f_{obj}(x) = (x (c_{obs}-p_{obs})+K)-mean \left(x
% (c_{obs}-p_{obs})\right)+K U_0$.
%
% 
%% Strike boundaries
% This tool allows for changing/adding strike boundaries. 
%
% *Note:* press "Apply tool" to confirm any change that has been made.
%
% The put price related to lower boundary is assumed 
% (and set) to be 0. The call price at lower boundary and put price at upper 
% boundary are inferred by linear interpolation. 
% Consequently, all values of the risk-neutral density outside this 
% interval are automatically truncated to 0 and it is recommenadable
% that this interval is properly set.
%
% The fictional prices that are generated together with the new boundaries
% are needed only to preserve consistency in the structure of the dataset 
% and will *never* be considered in the estimation procedure. Adding new 
% strikes to the original data will affect the estimation as follows:
%
% * The lower strike always represents a right-displacement of the kernel 
%     support (set this value to 0 to have no displacement).
% * The upper strike represents a truncation upper value for the kernel domain,
%     which is used to ensure that the RND does not take negative value. This
%     value does not affect the estimation provided that it is set sufficiently large.
%
% A good criterion to be adopted for the choce of the strike boundaries is 
% to run the method with order set to 0. When the values of "Estimation" 
% and "Global" residuals are close enough (e.g. have same magnitude) the 
% chosen interval can be considered "sufficiently informative". The automatic
% estimation based on linear interpolation normally provides good starting 
% values that can be fine-tuned by trial and error approach. 
%
