%% Loading/saving data
%
% Input data can be loaded by pressing "Open" in the main window. Many
% dataset formats are supported, however they must always contain the
% following data: strike values, call prices, put prices.
% 
%% MAT-file input data structure 
% The standard compatible format for input data is a MAT-file with the 
% following structure:
%
%  Variable name: [Size Type]  
%
%
%              K: [Mx1 double]  -----
%           call: [Mx1 double]       | Mandatory
%            put: [Mx1 double]       |
%              m: [2x1 double]  -----  
%        obsDate: [1x6 int]     -----
%        expDate: [1x6 int]          |
%         call_a: [Mx1 double]       | Optional
%         call_b: [Mx1 double]       |
%          put_a: [Mx1 double]       |
%          put_b: [Mx1 double]  -----
% 
% Mandatory variables:
%
% 
% *            K: vector of strike values
% *         call: vector of observed call prices
% *          put: vector of observed put prices
% *            m: vector containing guessed mean and variance 
%                 (can be set to [])
%
% Optional variables:
%
% *      obsDate: observation date in numeric format 'yyyy mm dd'
% *      expDate: expiry date in numeric format 'yyyy mm dd'
% *       call_a: vector of call ask prices
% *       call_b: vector of call bid prices
% *        put_a: vector of put ask prices
% *        put_b: vector of put bid prices
%
%% Supported external sources
% Input data can also be loaded from external sources and optionally 
% converted into compatible MAT-file format. Note that normally loading
% MAT-formatted data is faster.
% 
% *OptionMetrics*
%
% Option data must have .xls, .xlsx or .csv extension and formatted with 
% all default options (e.g. date format) preset in the OptionMetrics 
% download page. All columns related to mandatory variables must be 
% contained in the dataset. Other field can be appended at any position of 
% the spreadsheet. Options with several maturities and/or observation dates
% can be collected into the same file, in this case the user will be asked
% to make a choice. 
%
% Website:
% <http://www.optionmetrics.com/>
%
% *CBOE*
%
% Data may be saved either into default .dat format available at CBOE 
% website or may be pre-converted into .xls/.xlsx format. Data must contain
% all fields related to mandatory variables. Additional fields can be 
% appended in any position of the dataset. Data for several maturities can 
% be collected into the same file, in this case the user will be asked to 
% choose a maturity when loading data. 
%
% Website:
% <http://www.cboe.com/>
%