%% How to set order, kernel and method
% It is assumed that the risk-neutral density $f$ associated with the input 
% data can be expanded as
%
% $f(x) \sim \phi(x) \left(1+\sum_{k=1}^{n} \varepsilon_k(x)\right)$
%
% where $\phi$ is a kernel density and $\varepsilon_k$ are corrective
% factors, defined as
%
% $\varepsilon_k(x) := c_k h^{\phi}_k(x), \quad x \in supp(f)$
%
% where coefficients $c_k$ are constants and embed all the information on 
% $f$, while $h^{\phi}_k$ is a polynomial function of degree
% $k$, that only depends on the choice of $\phi$.
% 
% The coefficients $c_k$ can be estimated by three alternative linear 
% regression method.
%
%% Order
% The expansion order is the number $n$ in the sum above. In principle,
% when convergence is guaranteed, increasing this number should also
% increase the accuracy of the approximation. However, in the practice,
% there are two factors that may negatively influence convergence:
% 
% * Theoretical issues: convergence conditions depend on the asymptotic 
% behavior of $\frac{f^2}{\phi}$. Therefore, they might not be respected for
% any choice of the kernel and consequently lead to divergence as $n$
% grows.
%
% * Numerical issues: for high values of $n$ high order polynomials are
% involved in the numerical computations, mainly of integrals and matrix 
% inversion. Then computational issues may arise, depending on the estimation
% method being used.
% 
% Optimal values of the order are normally between 10 and 15.
%
%
%% Method
% There are three methods available to estimate coefficients $c_1, \ldots, c_n$:
%
% * Iterative: by this method a coefficient-by-coefficient estimation is
% performed and additional stability conditions can be imposed within the
% procedure. This is the most stable method and should not return divergent
% results even for high values of $n$, even if in this case it still might 
% get affected by issues related with overfitting. Moreover, as options data
% typically display multicollinearity, then this method is statistically
% weak. This method is generally the most performant when input data is
% simulated and does not display inconsistencies or violations of pricing
% theoretical principles.
%
% * OLS: by this method the estimation is made by means of ordinary least 
% squares approach. This is the simplest but weakest method, as any consistency
% condition is diregarded, wither from an analytical or a statistical point
% of view. Expansions with order higher than $10$ are unlikely to provide
% good results by this method.
%
% * PCA: by this method the estimation of $c_1, \ldots, c_n$ is made by resorting
% the most informative coefficients according to the selective procedure of
% principal component analysis. This method generally proves an efficient
% solution to overfitting and multicollinearity. When the estimation is made
% on real data that typically exhibit some inconsistencies, this method 
% generally provides the best performance. Optionally, the PCA can be
% constrained to provide positive densities and centered residuals.
%
% Note that in all cases it is possible to exclude some data from the 
% estimation without being necessary to edit the input file. This can
% be done by setting the value displayed in the field named "Cutting threshold".
% All couples of call and put prices such that one price is below the threshold
% are excluded from the estimation, together with related strikes.
%
%
%% Kernel
% To guarantee a convergent expansion, the tails of $\phi$ must be dominated
% by the tails of $f$. Hence, an heavy-tailed kernel would make convergence 
% easier to be met. On the other hand, the right tail of $\phi$ must decay 
% at an appropriate fast rate to ensure that in the limit, the expansion,
% converges exactly to the RND. 
%
% The following kernels are available to the user by default:
%
% * Beta
%
% $(\frac{x}{c})^{a-1} (1-\frac{x}{c})^{b-1}, \quad 0\leq x \leq c$
%
% * Cox-Ingersoll-Ross
%
% See <http://www.jstor.org/stable/1911242?seq=1#page_scan_tab_contents>
%
% * Double beta
%
% $\omega (\frac{x}{c_1})^{a_1-1} (1-\frac{x}{c_1})^{b_1-1} + (1-\omega) (\frac{x}{c_2})^{a_2-1} (1-\frac{x}{c_2})^{b_2-1}, \quad 0\leq x \leq \max(c_1,c_2)$
%
% * Gamma
%
% $x^{\alpha-1} e^{-\beta x}, \quad x\geq 0$
%
% * Generalized Inverse Gaussian (GIG)
%
% $x^{\alpha-1} e^{-\frac{1}{2}\left(\beta x+\xi x^{-1}\right)}, \quad x \geq 0$
%
% * Generalized Weibull (Gen. Weibull)
%
% $x^{\alpha-1} e^{-\beta x^p}, \quad x\geq 0$
%
% * Lognormal
%
% $\frac{1}{x}e^{-\frac{1}{2 \sigma^2}\left( \log(x)-\mu \right)^2}, \quad x\geq 0$
%
% Normally, Generalized Inverse Gaussian and Generalized Weibull are better
% choices for volatility related options and the Double beta is better
% suited to SPX options.
%%