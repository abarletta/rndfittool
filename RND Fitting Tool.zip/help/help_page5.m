%% Exporting results
% 
%% Exporting modified input data
% Input data can always be exported into a comptabile MAT-file, regardless
% of the source it was loaded from. This can be done by opening the data
% editor through  "Edit input data" in the main window, and then selecting
% "Export input data".
%
%% Exporting output
% Output can be exported in two ways and only after "Run" has been pressed
% at least once. There are two ways to export output:
%
% * Exporting graphics: by "Export plot" all plots displayed in the current 
% window will be saved into three image files. Aspect ratio and extension 
% of the exported images can be chosen by the user.
% 
% * Exporting all data: by "Export results" current results will be
% exported into a MAT-file with the following structure:
%
%           K: [Mx1 double]          -------
%     obsCall: [Mx1 double]                 | Input data
%      obsPut: [Mx1 double]          -------
%           c: [1x(order+1) double]  ------- 
%      kerPar: [1xP double]                 |
%           f: function handle              | Output data
%          kf: function handle              |               
%       order: [1x1 int]                    |
%      kernel: [1xD char]            ------- 
%
% Description of exported variables:
%
% * |K, obsCall, obsPut| : undiscounted input prices that include also
%                          modifications made in "Edit input data".
% * |c| : expansion coefficients.
% * |kerPar| : vector containing kernel defining parameters.
% * |f| : function handle to the approximated density.
% * |kf| : function handle to the kernel density truncated to zero outside
%          strikes interval.
% * |order| : expansion order.
% * |kernel| : kernel type.