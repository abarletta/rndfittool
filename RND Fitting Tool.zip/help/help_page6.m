%% Greeks
%
% The Delta and the Gamma of the observed call prices can be computed for 
% by clicking on "Find greeks".
%
%% Methodology
%
% The methodology is non-structural and a full description will be soon 
% available in the following paper:
%
% Barletta A, Santucci de Magistris P, Sloth D. _Non-structural Greeks._
% Work in progress.
%