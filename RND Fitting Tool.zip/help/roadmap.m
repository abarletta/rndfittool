%% Risk-Neutral Density Fitting Tool
%
% 
% 
% <<logo.png>>
% 
%
% This toolbox provides a GUI to infer the risk-neutral pdf associated with 
% financial assets on which call and put options are traded. The 
% approach is fully non-structral and is described in the work available at
%
% <http://pure.au.dk/portal/files/101068557/rp16_20.pdf>
%
% Option data can be directly imported from the GUI and several formats, 
% including OptionMetrics and CBOE native formats, are accepted. Editing 
% tools are also included in the toolbox, in order to check for prices 
% inconsistencies and optionally correct them.