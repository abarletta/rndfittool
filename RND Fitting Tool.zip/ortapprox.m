%% ORTAPPROX - ortogonal approximation
%
% f=ortapprox(kf, KerMom, c)
%
% Last modified: September 2016

function f=ortapprox(kf, w, c)

a=flip(w'*c');
f=@(x) kf(x).*polyval(a,x);

end % END OF FUNCTION
