function matlabData=impCBOE(varargin)

fname=varargin{1};

%% Reading data according to file extension
if strcmp(fname(end-2:end),'dat')==1
    fileID=fopen(fname);
    C = textscan(fileID, ...
        '%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s', ...
        'delimiter',',');
    fclose(fileID);
    try
        txt=cell(length(C{1}),length(C));
    catch ME
        matlabData=[];
    end
    for i=1:22
        txt(:,i)=C{i};
    end
else
    try
        [data,txt]=xlsread(fname);
    catch ME
        matlabData=[];
    end
end
tot=6;
N=size(txt);
if nargin==1
    waitMessage=waitbar(0, 'Importing data from CBOE format...');
end

%% Main Code
try
    %% Reading observation date
    obsDatePos=[];
    i=0;
    while (isempty(obsDatePos)==1)&&(i<N(1))
        i=i+1;
        j=0;
        while (isempty(obsDatePos)==1)&&(j<N(2))
            j=j+1;
            if sum(char(txt(i,j))=='@')==1
                obsDatePos=[i j];
            end
        end
    end
    
    if isempty(obsDatePos)==1
        if nargin==1
            msgbox('Observation date was not found. Possible file corruption.', ...
                'Importing data', 'error');
        end
    else
        obsDate=datevec(txt(obsDatePos(1),obsDatePos(2)),'mmm dd yyyy');
    end
    
    if nargin==1
        waitbar(1/tot);
    end
    
    %% Determining columns of call and put options
    callPos=[];
    putPos=[];
    keepOn=1;
    i=0;
    while (keepOn==1)&&(i<N(1))
        i=i+1;
        j=0;
        while (keepOn==1)&&(j<N(2))
            j=j+1;
            if strcmpi(char(txt(i,j)),'calls')==1
                callPos=[i j];
            end
            if strcmpi(char(txt(i,j)),'puts')==1
                putPos=[i j];
            end
            keepOn=(isempty(callPos)==1)||(isempty(putPos)==1);
        end
    end
    
    if (isempty(callPos)==1)||(isempty(putPos)==1)
        if nargin==1
            msgbox('Data on option prices was not found. Possible file corruption.', ...
                'Importing data', 'error');
            error('Data on option prices was not found. Possible file corruption.');
        end
    end
    
    %% Reading expiration dates
    expDatePos=[];
    i=0;
    while (isempty(expDatePos)==1)&&(i<N(1))
        i=i+1;
        j=0;
        while (isempty(expDatePos)==1)&&(j<N(2))
            j=j+1;
            if strcmpi(char(txt(i,j)),'expiration date')==1
                expDatePos=[i j];
            end
        end
    end
    
    if isempty(expDatePos)
        if nargin==1
            msgbox('No valid expiration date was not found. Possible file corruption.', ...
                'Importing data', 'error');
        end
    end
    
    expDate=unique(datevec(txt(expDatePos(1)+1:end,expDatePos(2))),'rows');
    
    if rows(expDate)>1
        % User selects desired expiration date
        if nargin==1
            [~, ind]=selmat(expDate);
        else
            ind=1;
        end
        expDate=expDate(ind,:);
        expDateInd=...
            sum(datevec(txt(expDatePos(1)+1:end,expDatePos(2)))==expDate,2)==6;
    else
        ind=1;
        expDateInd=[expDatePos(1)+1; N(1)];
    end
    
    errFlag=0;
    if nargin==1
        waitbar(2/tot);
    end
    
    %% Reading call options
    
    % Discharging call options marked with other suffixes
    labels=txt(callPos(1)+1:N(1),callPos(2));
    for i=1:length(labels)
        tmp=labels{i};
        if isempty(tmp)==0
            if (strcmp(tmp(end-2),'-'))||(strcmp(tmp(end-2),'.'))
                expDateInd(i)=false;
            end
        end
    end
    
    % Finding strikes related to call options
    K_C=txt(callPos(1)+1:end,callPos(2));
    K_C=K_C(expDateInd);
    I=strfind(K_C{1},'C');
    I=I(end);
    K_C=char(K_C);
    K_C=str2num(K_C(:,I+1:end))/1000;
    
    if nargin==1
        waitbar(3/tot);
    end
    
    % Finding bid and ask prices
    if strcmpi(char(txt(callPos(1),callPos(2)+3)),'bid')==1
        C_b=txt(callPos(1)+1:end,callPos(2)+3);
        C_b=str2num(char(C_b(expDateInd)));
    else
        errFlag=1;
    end
    
    if (errFlag==0)&&(strcmpi(char(txt(callPos(1),callPos(2)+4)),'ask')==1)
        C_a=txt(callPos(1)+1:end,callPos(2)+4);
        C_a=str2num(char(C_a(expDateInd)));
    else
        errFlag=1;
    end
    
    % Setting mid-prices
    if (errFlag==0)
        if isequal(C_a,C_b)==1
            C_a=[];
            C_b=[];
            if (strcmpi(char(txt(callPos(1),callPos(2)+1)),'last sale')==1)
                C=txt(callPos(1)+1:end,callPos(2)+1);
                C=str2num(char(C(expDateInd)));
            else
                errFlag=1;
            end
        else
            C=(C_a+C_b)/2;
        end
    end
    
    if nargin==1
        waitbar(4/tot);
    end
    
    %% Reading put options
    
    % Discharging call options marked with other suffixes
    labels=txt(putPos(1)+1:N(1),putPos(2));
    labels=labels(expDateInd,:);
    strInd=[];
    for i=1:length(labels)
        tmp=labels{i};
        if isempty(tmp)==0
            if (ne(tmp(end-2),'-')==1)&&ne(tmp(end-2),'.')
                strInd=[strInd;i];
            end
        end
    end
    
    % Finding strikes related to call options   
    K_P=txt(putPos(1)+1:end,putPos(2));
    K_P=K_P(expDateInd);
    I=strfind(K_P{1},'P');
    I=I(end);
    K_P=char(K_P);
    K_P=str2num(K_P(:,I+1:end))/1000;
    
    
    
    if nargin==1
        waitbar(3/tot);
    end
    
    % Finding put options
    
    if (errFlag==0)&&strcmpi(char(txt(putPos(1),putPos(2)+3)),'bid')==1
        P_b=txt(putPos(1)+1:end,putPos(2)+3);
        P_b=str2num(char(P_b(expDateInd)));
    else
        errFlag=1;
    end
    
    if (errFlag==0)&&(strcmpi(char(txt(putPos(1),putPos(2)+4)),'ask')==1)
        P_a=txt(putPos(1)+1:end,putPos(2)+4);
        P_a=str2num(char(P_a(expDateInd)));
    else
        errFlag=1;
    end
    
    % Setting mid-prices
    if (errFlag==0)
        if isequal(P_a,P_b)==1
            P_a=[];
            P_b=[];
            if (strcmpi(char(txt(putPos(1),putPos(2)+1)),'last sale')==1)
                P=txt(putPos(1)+1:end,putPos(2)+1);
                P=str2num(char(P(expDateInd)));
            else
                errFlag=1;
            end
        else
            P=(P_a+P_b)/2;
        end
    end
    
    if nargin==1
        waitbar(5/tot);
    end
    
    %% Setting final structure
    
    if errFlag==1
        if nargin==1
            msgbox('Data on option prices was not found. Possible file corruption.', ...
                'Importing data', 'error');
            error('Data on option prices was not found. Possible file corruption.');
        end
    else
        % Finding common strikes
        [K,ia,ib] = intersect(K_C,K_P);
        C=C(ia);
        P=P(ib);
        if isempty(P_a)==0
            P_a=P_a(ib);
        end
        if isempty(P_b)==0
            P_b=P_b(ib);
        end
        if isempty(C_a)==0
            C_a=C_a(ia);
        end
        if isempty(C_b)==0
            C_b=C_b(ia);
        end
        
        % Sorting data
        [K,index]=sort(K);
        call=C(index);
        
        put=P(index);
        if isempty(C_a)==0
            call_a=C_a(index);
        else
            call_a=[];
        end
        if isempty(C_b)==0
            call_b=C_b(index);
        else
            call_b=[];
        end
        if isempty(P_a)==0
            put_a=P_a(index);
        else
            put_a=[];
        end
        if isempty(P_b)==0
            put_b=P_b(index);
        else
            put_b=[];
        end
        
        %         max_K=find(call_b==min(call_b),1);
        %         max_K=length(K);
        %         K=K(1:max_K);
        %         call=call(1:max_K);
        %         put=put(1:max_K);
        %         call_a=call_a(1:max_K);
        %         call_b=call_b(1:max_K);
        %         put_a=put_a(1:max_K);
        %         put_b=put_b(1:max_K);
        %
        % Moment vector (empty)
        m=[];
        
        % Interest rate (set to zero)
        r=0;
        
        % Exporting data
        matlabData=struct;
        matlabData.K=K;
        matlabData.call=call;
        matlabData.put=put;
        matlabData.m=m;
        if isempty(call_a)==0
            matlabData.call_a=call_a;
        end
        if isempty(call_b)==0
            matlabData.call_b=call_b;
        end
        if isempty(put_a)==0
            matlabData.put_a=put_a;
        end
        if isempty(put_b)==0
            matlabData.put_b=put_b;
        end
        matlabData.obsDate=obsDate;
        matlabData.expDate=expDate;
        matlabData.r=r;
        if nargin==1
            waitbar(6/tot);
        end
    end
    
catch ME
    matlabData=[];
end

if nargin==1
    close(waitMessage);
end
